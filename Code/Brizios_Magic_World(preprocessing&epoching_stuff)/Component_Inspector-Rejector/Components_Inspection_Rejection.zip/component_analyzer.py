# -*- coding: utf-8 -*-
"""
Created on Mon Jun 24 16:03:15 2019

@author: Fabrizio Zoleo
"""

import matlab.engine as mateng
import sys

from os import listdir, system
from os.path import join

def isRoundFolder(fname):
   return ( "R" in fname.upper()) or ("ROUND" in fname.upper() ) 

def isFullyProcessed(file, hpf_freq):
    hpf = "hpf" + str(hpf_freq)
    return (".set" in file) and (hpf in file) and ("ICA" in file) and ("ep" not in file) and ("pruned" not in file)

# Cleaning the shell
if sys.platform == "linux" or sys.platform == "linux2":
    system("clear")
elif sys.platform == "win32":
    system("cls")
    system("mode con: cols=130 lines=40")
    
path = ""
hpf = ""
# Reading PATH parameter from command line or asking it in input if not provided
if len(sys.argv) == 2:
    path = sys.argv[1]
    hpf = float(input("Please insert the HIGH-PASS filter frequency used for pre-process data: "))
elif len(sys.argv) == 3:
    path = sys.argv[1]
    hpf = sys.argv[2]
else:
    path = input("Please insert the folder path containing the rounds to be analyzed:\n")
    hpf = float(input("Please insert the HIGH-PASS filter frequency used for pre-process data: "))
# Reading the type of cleaned dataset to read
erp = input("\nDo you want to inspect pre-processed data for ERP analysis? (Y/N): ").upper()

if erp == 'Y':
    hpf = 0.1
    
# Starting MATLAB engine
print("\nLoading rounds . . .\n")
engine = mateng.start_matlab()
round_dirs = listdir(path)
round_dirs.sort()

for d in round_dirs:
    if isRoundFolder(d):
        print("\nRound Directory:\t{}\n\n".format(d))
# Retrieving the fully pre-processed dataset      
        current_path = join(path, d)
        dir_ds = [f for f in listdir(current_path) if isFullyProcessed(f, hpf)]
        cleaned_ds = None
# Plotting raw data and spectra for channels and components
        for ds in dir_ds:
            print("\nDataset inspected:\t {}\n\n".format(ds))
            print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            engine.plot_components(current_path, ds, nargout=0)
            cleaned_ds = ds
            
        prune = input("\n\nDo you want to reject any component? (Y/N): ").upper()
# Reading the components to be rejected        
        if prune == "Y":
            components = input("\n\n\nPlease enter the component indices to remove from data (ex. 1,2,3 or 1 2 3):\n").replace(" ", '')
            components = list( components.replace(',' , '') )
            components = list( map(int, components) )
            print("\nThe specified components {} will be removed.\n\n".format(components))
        else:
            components = ''
            
# Running the script for rejecting selected components and extracting epochs     
        engine.prune_components(current_path, cleaned_ds[:cleaned_ds.rfind('.')], components, nargout=0)
            
        input("\nPress ENTER to inspect the next round, press CTRL+Z and ENTER if you want to abort . . .\n")
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")

print("Last round was inspected.\n")