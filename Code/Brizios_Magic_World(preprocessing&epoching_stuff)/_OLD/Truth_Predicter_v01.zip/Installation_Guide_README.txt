- - - - - - FRAMEWORK SETUP - - - - - - 
First of all, be sure to have MATLAB installed on your PC together with EEGLAB. If you haven't installed yet, you can download them from:
- MATLAB (v. R2019a) 	https://www.mathworks.com/downloads/
- EEGLAB (v. 14_1_2b) 	https://sccn.ucsd.edu/eeglab/download.php

Once they are installed and correctly set for working, be sure to install the following plugins in EEGLAB (File -> Manage EEGLAB extensions):
- select "Data import extensions" and search for the "musemonitor" plugin, then check it and click "OK" to install;
- select "Data Processing extensions" and search for the "Cleanline", "clean_rawdata" and "firfilt" plugins, then check them and click "OK" to install.

Now your framework has all that is needed to apply the pre-processing pipeline to data recorded with the MuseMonitor app.


- - - - - - PYTHON ENVIRONMENT SETUP - - - - - - 
Be sure you have installed Python 3.7.3 on your computer. If you haven't installed yet, you can download it from the official page of Python:
https://www.python.org/downloads/

After the installation, update the SYSTEM ENVIRONMENT VARIABLES:
1) Go on the "Properties" of "My Computer", then select "Advanced System settings"
2) Click on "Environment Variables"
3) In the bottom box, search for the PATH variable and double-click on it
4) Be sure that the Python installation folder and Python\Scripts folder are listed, otherwise add them 
5) Be sure that the MATLAB installation folder is listed, otherwise add it

Now the system environment should be set up; to check it, open the Terminal and run the command "python": you should see the version of python
installed. Press CTRL+Z to quit from Python.

The next step is to install all the packages and libraries needed in Python:
1) Open the Terminal as Administrator and run the following commands:
	- pip -m install pandas 	(Pandas and Numpy libraries installation)
	- pip -m install matlab_kernel  (MATLAB kernel for Python)
2) In the terminal, move to the MATLAB installation folder (es. C:\Program Files\MATLAB\R2019a)
3) Move to the subfolder "extern\engines\python"
4) Run the following command:
	- py setup.py install --prefix="PythonInstallDirectory"  (Insert the path of Python installation directory, this is only a placeholder)

Now you should have all set up for running the pre-processing application!


- - - - - - APPLICATION SETUP AND INSTRUCTIONS- - - - - - 
1) Extract the archive in the folder that you prefer
2) Open the Terminal and move to the folder in which files was extracted
3) Run "automated_preprocessing.py" to process data in all rounds for a subject
4) Run "component_analyzer.py" to inspect processed raw data, computed components and their spectra; eventually, you can specify the components
   to be rejected from data and see the results. After the inspection of a single round, the program will extract target and not-target epochs.

In order to run the application correctly, keep in mind that the "automated_preprocessing.py" script will work on a well-structured hierarchy of
folders, that should be organized as following:

- SubjectName
	- R01
	- R02
	   .
	   .
	   .
	- RN

Each subfolder in the "SubjectName" folder should correspond to a single Round and must contain at least the CSV file recorded with the MuseMonitor app and the 
JSON file containing the timestamps recorded during the experiment. 
Round folders must have the name "RN" or "ROUNDN" (case non-sensitive), where "N" is the number of the round on at least two digits. 
Example:
 	Round num. 1 -> "R01" or "ROUND01"  

Round subfolders can be put in other subfolders under the "SubjectName" folder, in which case the working folder requested from the applications must be this
subfolder because the applications will search the round folders there.
Example:
  - SubjectName
	- Alternative_Subfolder1
		- R01
		- R02
		   .
		   .
	- Alternative_Subfolder2
		- R01
		- R02
		- R03

Working path provided to the application: "...\SubjectName\Alternative_Subfolder1" to process rounds in Alternative_Subfolder1.


Finally, the two applications will ask some parameters in input, but some of them can be provided from command line as parameters when running the command 
for executing the applications. The parameters you can provide from command line are the following:
- "automated_preprocessing.py" -> 1^ parameter: WORKING_PATH 
- "component_analyzer.py" -> 1^ parameter: WORKING_PATH ;  2^ parameter: HIGH-PASS_FILTER_FREQUENCY with which the first pre-processing pass has been performed

The command line parameters are not mandatory, if not provided will be requested from the application. For the "component_analyzer.py" application, you can 
specify either both parameters or only the first one, but you cannot specify the second parameter without the first one.
