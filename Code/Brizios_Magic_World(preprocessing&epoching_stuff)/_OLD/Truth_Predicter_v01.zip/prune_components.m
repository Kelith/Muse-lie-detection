function prune_components(path, file_name, components)
    [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
    fprintf('\nLOADING DATASET . . .\n');
    steps = file_name;
    EEG = pop_loadset('filename', strcat(file_name, '.set'), 'filepath', path);
    [ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
    EEG = eeg_checkset( EEG );
    
    if ~isempty(components)
        fprintf('\nREMOVING COMPONENTS . . .\n');
        components = cell2mat(components);
        EEG = pop_subcomp( EEG, components, 0);
        steps = strcat(steps, '_pruned');
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'setname', steps, 'savenew', strcat(path,'\\',steps,'.set'), 'gui','off');
        % Plot of channels' continuous data
        pop_eegplot( EEG, 1, 1, 1);
        EEG = eeg_checkset( EEG );
        % Plot of channels' spectra
        figure; pop_spectopo(EEG, 1, [EEG.xmin      EEG.xmax], 'EEG' , 'freqrange',[1 128],'electrodes','off');
        EEG = eeg_checkset( EEG );
    end
    
    % Extracting Target and Not-Target epochs
    fprintf('\nEXTRACTING TARGET EPOCHS . . .\n');
    EEG = pop_epoch( EEG, {  'start-question-isTarget'  'start-question-isYes'  }, [-1  3], 'newname', strcat(steps, '_epIsTarget'), 'epochinfo', 'yes');
    
    if isempty(components)
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'savenew',strcat(path, '\\', steps, '_epIsTarget.set'), 'gui','off'); 
        EEG = eeg_checkset( EEG );
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'retrieve',1,'study',0); 
        EEG = eeg_checkset( EEG );  
        fprintf('\nEXTRACTING NOT-TARGET EPOCHS . . .\n');
        EEG = pop_epoch( EEG, {  'start-question-notTarget'  }, [-1  3], 'newname', strcat(steps, '_epNotTarget'), 'epochinfo', 'yes');
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'savenew',strcat(path, '\\', steps, '_epNotTarget.set'),'gui','off'); 
    else
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',strcat(path, '\\', steps, '_epIsTarget.set'), 'gui','off'); 
        EEG = eeg_checkset( EEG );
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 3,'retrieve',2,'study',0); 
        EEG = eeg_checkset( EEG );
        fprintf('\nEXTRACTING NOT-TARGET EPOCHS . . .\n');
        EEG = pop_epoch( EEG, {  'start-question-notTarget'  }, [-1  3], 'newname', strcat(steps, '_epNotTarget'), 'epochinfo', 'yes');
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',strcat(path, '\\', steps, '_epNotTarget.set'),'gui','off'); 
    end
    
    fprintf('\nEXTRACTING NOT-TARGET EPOCHS . . .\n');
    EEG = pop_epoch( EEG, {  'start-question-notTarget'  }, [-1  3], 'newname', strcat(steps, '_epNotTarget'), 'epochinfo', 'yes');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'savenew',strcat(path, '\\', steps, '_epNotTarget.set'),'gui','off'); 
    EEG = eeg_checkset( EEG );
    fprintf('\nCOMPLETED!\n');
end

