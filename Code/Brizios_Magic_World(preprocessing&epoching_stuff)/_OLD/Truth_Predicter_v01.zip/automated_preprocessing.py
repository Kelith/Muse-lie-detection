# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 09:42:15 2019

@author: Fabrizio Zoleo
"""

import matlab.engine as mateng
import sys

from datetime import datetime
from os import listdir, rename, system
from os.path import isfile, join

import Events_Generator.EventsGenerator as EG

def isFileType(fname, ftype):
    return fname[fname.find('.')+1 :].upper() == ftype.upper()

# Cleaning the shell
if sys.platform == "linux" or sys.platform == "linux2":
    system("clear")
elif sys.platform == "win32":
    system("cls")
    system("mode con: cols=130 lines=40")

path = ""
# Reading PATH parameter from command line or asking it in input if not provided
if len(sys.argv) == 2:
    path = sys.argv[1]
else:
    path = input("Please insert the folder path of the subject to be processed:\n")

# Reading the range of rounds to be processed   
rounds = input("\nPlease insert the range of rounds (ex. 1-9) or the single round to be processed: ").replace(" ",'')
if rounds.find('-') >= 0:    
    start_round = int( rounds[: rounds.find('-')] )
    end_round = int( rounds[rounds.find('-')+1 :] )
else:
    start_round = int(rounds)
    end_round = start_round
    
# Reading parameters for pre-processing data
hpf = float( input("\nInsert the FREQUENCY value in Hz for the HIGH-PASS FILTER: ") )

std = float( input("\nInsert the STD value (Standard Deviation) for ASR (-1 to disable): ") )
if std <= 0:
    std = -1

subject = input("\nPlease, enter the name of the subject (spaces not allowed, use _ instead): ").replace(" ", '_')

if std >= 0:
    print("\n\nSTD value for ASR is {} . Pre-processing pipeline alternative with ASR will be applied!".format(std))
else:
    print("\n\nASR step turned off. Pre-processing pipeline alternative with Continuous Data Rejection will be applied!")

print("\nWARNING: to be correctly processed, the folder structure for a subject must be of the type:\n-SubjectName\n\t-R1\n\t-R2\n\t .\n\t .\n\t .\n\t-RN")
input("\nPress ENTER to start . . .\n")

# Starting MATLAB engine
engine = mateng.start_matlab()
start = datetime.now()
print("\nProcessing data started at {}".format(start) )
# Generating Events for each round of the subject
print("\nSUBJECT: {}".format(subject))
for i in range(start_round, end_round + 1):
    print("\n- - - - ROUND {} - - - -\n".format(i) )
    current_path = path + "\\R" + str(i)
    print(current_path)
    files = [f for f in listdir(current_path) if isfile(join(current_path, f)) and ( isFileType(f,"csv") or isFileType(f,"json") )]
# Renaming files
    new_name = subject + str(i)
    csv_file = None
    if isFileType(files[0], "csv"):
        rename( join(current_path, files[0]), join(current_path, new_name + ".csv") )
        files[0] = new_name + ".csv"
        rename( join(current_path, files[1]), join(current_path, new_name + ".json") ) 
        files[1] = new_name + ".json"
        csv_file = files[0]
    else:
        rename( join(current_path, files[0]), join(current_path, new_name + ".json") )
        files[0] = new_name + ".json"
        rename( join(current_path, files[1]), join(current_path, new_name + ".csv") )
        files[1] = new_name + ".csv"
        csv_file = files[1]
# Extracting events
    EG.run(current_path, files[0], files[1])
    
# Executing the Pre-processing pipeline for the current round
    print("\nApplying the pipeline for cleaning data . . . ")
    
    if std > 0:
        print("Parameters:\nPATH= {}\nRAW_DATA_FILE= {}\nROUND= {}\nHIGH-PASS_FILTER_FREQ= {}\nSTD= {}".format(path, csv_file, i, hpf, std))
# First pass: cleaning with ASR and computing ICA Weight Matrix
        engine.preprocessing_pipeline(path, csv_file[:csv_file.find('.')], str(i), hpf, std, '', nargout=0)
        print("\n\n- - - 1st PASS CONCLUDED - - -\nStarting the 2nd pass . . .\n\nHIGH-PASS_FILTER_FREQ= 0.1")
# Second pass: low-pass filter at 0.1 and applying ICA Weight Matrix computed before
        engine.preprocessing_pipeline(path, csv_file[:csv_file.find('.')], str(i), 0.1, std, 'ica_weights', nargout=0)
    else:
        print("Parameters:\nPATH= {}\nRAW_DATA_FILE= {}\nROUND= {}\nHIGH-PASS_FILTER_FREQ= {}\nSTD= OFF".format(path, csv_file, i, hpf))
# First pass: cleaning with Automatic Continuous Data Rejection and computing ICA Weight Matrix
        engine.preprocessing_pipeline(path, csv_file[:csv_file.find('.')], str(i), hpf, std, '', nargout=0)
        print("\n\n- - - 1st PASS CONCLUDED - - -\nStarting the 2nd pass . . .\n\nHIGH-PASS_FILTER_FREQ= 0.1")
# Second pass: low-pass filter at 0.1 and applying ICA Weight Matrix computed before
        engine.preprocessing_pipeline(path, csv_file[:csv_file.find('.')], str(i), 0.1, std, 'ica_weights', nargout=0)
    
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    
end = datetime.now()
print("\n\nProcessing data completed at {}\nElapsed time: {}".format(end, (end - start)) )
