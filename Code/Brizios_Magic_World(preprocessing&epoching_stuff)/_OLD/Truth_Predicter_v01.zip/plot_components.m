function plot_components(path, file_name)
    close all force;
    [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
    % Loading the dataset
    EEG = pop_loadset('filename',file_name,'filepath', path);
    [ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
    EEG = eeg_checkset( EEG );
    % Plot of channels' continuous data
    pop_eegplot( EEG, 1, 1, 1);
    EEG = eeg_checkset( EEG );
    % Plot of channels' spectra
    figure; pop_spectopo(EEG, 1, [EEG.xmin      EEG.xmax], 'EEG' , 'freqrange',[1 128],'electrodes','off');
    EEG = eeg_checkset( EEG );
    % Plot of components' properties (Spectra, Scalp Maps)
    pop_eegplot( EEG, 0, 1, 1);
    % Plot of components' continuous data
    pop_prop( EEG, 0, [1  2  3  4], NaN, {'freqrange' [1 128] });
end

