function extract_epochs(path, file_name)
    close all force;
    
    [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
    EEG = pop_loadset('filename',strcat(file_name, '.set'),'filepath', path);
    [ALLEEG, EEG, CURRENTSET] = eeg_store( ALLEEG, EEG, 0 );
    EEG = eeg_checkset( EEG );
    
    % Extracting the dataset with TARGET epochs
    disp("Extracting TARGET epochs . . .");
    EEG = pop_epoch( EEG, {  'start-question-isTarget'  'start-question-isYes'  }, [-1           3], 'newname', strcat(file_name, '_epIsTarget'), 'epochinfo', 'yes');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'savenew',strcat(path, '\\Extracted_Epochs\\', file_name, '_epIsTarget.set'),'gui','off'); 
    %xmin = EEG.xmin * 1000;
    %xmax = EEG.xmax * 1000;
    STARTING_DS = CURRENTSET;
    % Extracting EEG data and spectra
    %disp("Exporting TARGET EEG data and spectra . . .");
    %pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_EEG.csv'),'transpose','on','precision',5);
    %figure; spect = pop_spectopo(EEG, 1, [xmin      xmax], 'EEG' , 'freqrange',[1 128],'electrodes','off');
    %csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_EEG-SPECTRA.csv'), spect);
    EEG = eeg_checkset( EEG );
    % Extracting components data and spectra, if ICA was performed
    %if size(EEG.icaweights) ~= 0
    %    disp("Exporting TARGET ICA_components data and spectra . . .");
    %    pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_ICA.csv'),'ica', 'on', 'transpose','on','precision',5);
    %    figure; spect = pop_spectopo(EEG, 0, [xmin      xmax], 'EEG' , 'freq', [10], 'plotchan', 0, 'icacomps', [1:4], 'nicamaps', 5, 'freqrange',[1 100],'electrodes','off');
    %    csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_ICA-SPECTRA.csv'), spect);
    %end
    % Separating TARGET single-epochs and extracting data and spectra of each one 
    disp("Extracting TARGET single-epochs and exporting data/spectra . . .");
    for i = 1:EEG.trials
        i_str = num2str(i);
        if i < 10
            i_str = strcat('0', i_str);
        end
        % Extracting and isolating the selected epoch
        EEG = pop_select( EEG,'trial',i);
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'setname',strcat(file_name, '_epIsTarget_e', i_str), 'savenew', strcat(path, '\\Extracted_Epochs\\', file_name, '_epIsTarget_e', i_str,'.set'), 'gui','off'); 
        EEG = eeg_checkset( EEG );
        xmin = EEG.xmin * 1000;
        xmax = EEG.xmax * 1000;
        % Exporting EEG data, spectra and ersp of the single epoch
        pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_e', i_str, '_EEG.csv'),'transpose','on','precision',5);
        figure; spect = pop_spectopo(EEG, 1, [xmin      xmax], 'EEG' , 'freqrange',[1 128],'electrodes','off');
        csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_e', i_str, '_EEG-SPECTRA.csv'), spect);
        EEG = eeg_checkset( EEG );
        % Extracting ERSP for each channel
        for c = 1:EEG.nbchan
            caption = EEG.chanlocs(1,c).labels;
            figure; ersp = pop_newtimef( EEG, 1, c, [xmin  xmax], [3         0.5] , 'topovec', 1, 'elocs', EEG.chanlocs, 'chaninfo', EEG.chaninfo, 'caption', caption, 'baseline',[0],'winsize', 256, 'freqs', [0 60], 'plotphase', 'off', 'padratio', 1);
            csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_e', i_str, '_ERSP-', caption,'.csv'), ersp);
        end    
        % Exporting ICA_components data and spectra of the single epoch, if ICA was performed
        if size(EEG.icaweights) ~= 0
            pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_e', i_str, '_ICA.csv'),'ica', 'on', 'transpose','on','precision',5);
            figure; spect = pop_spectopo(EEG, 0, [xmin      xmax], 'EEG' , 'freq', [10], 'plotchan', 0, 'icacomps', [1:4], 'nicamaps', 5, 'freqrange',[1 100],'electrodes','off');
            csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_e', i_str, '_ICA-SPECTRA.csv'), spect);
            
            [n_components, ~] = size(EEG.icaweights);
            for c = 1:n_components
                figure; ersp = pop_newtimef( EEG, 0, c, [xmin  xmax], [3         0.5] , 'topovec', 1, 'elocs', EEG.chanlocs, 'chaninfo', EEG.chaninfo, 'caption', strcat('COMP0', c), 'baseline',[0],'winsize', 256, 'freqs', [0 60], 'plotphase', 'off', 'padratio', 1);
                csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epIsTarget_e', i_str, '_ERSP-', strcat('COMP0', c),'.csv'), ersp);
            end 
        end
        
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'retrieve', STARTING_DS, 'study',0);
        EEG = eeg_checkset( EEG ); 
        close all;
    end
    
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'retrieve',1, 'study',0);
    EEG = eeg_checkset( EEG ); 
    
    %Extracting the dataset with NOT-TARGET epochs
    disp("Extracting NOT-TARGET epochs . . ."); 
    EEG = pop_epoch( EEG, {  'start-question-notTarget' }, [-1           3], 'newname', strcat(file_name, '_epNotTarget'), 'epochinfo', 'yes');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'savenew',strcat(path, '\\Extracted_Epochs\\', file_name, '_epNotTarget.set'),'gui','off'); 
    %xmin = EEG.xmin * 1000;
    %xmax = EEG.xmax * 1000;
    STARTING_DS = CURRENTSET;
    % Extracting EEG data and spectra
    %disp("Exporting NOT-TARGET EEG data and spectra . . .");
    %pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_EEG.csv'),'transpose','on','precision',5);
    %figure; spect = pop_spectopo(EEG, 1, [xmin      xmax], 'EEG' , 'freqrange',[1 128],'electrodes','off');
    %csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_EEG-SPECTRA.csv'), spect);
    EEG = eeg_checkset( EEG );
    % Extracting components data and spectra, if ICA was performed
    %if size(EEG.icaweights) ~= 0
     %   disp("Exporting NOT-TARGET ICA_components data and spectra . . .");
      %  pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_ICA.csv'),'ica', 'on', 'transpose','on','precision',5);
       % figure; spect = pop_spectopo(EEG, 0, [xmin      xmax], 'EEG' , 'freq', [10], 'plotchan', 0, 'icacomps', [1:4], 'nicamaps', 5, 'freqrange',[1 100],'electrodes','off');
        %csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_ICA-SPECTRA.csv'), spect);
    %end
    % Separating NOT-TARGET single-epochs and extracting data and spectra of each one 
    disp("Extracting NOT-TARGET single-epochs and exporting data/spectra . . .");
    for i = 1:EEG.trials
        i_str = num2str(i);
        if i < 10
            i_str = strcat('0', i_str);
        end
        % Extracting and isolating the selected epoch
        EEG = pop_select( EEG,'trial',i);
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'setname',strcat(file_name, '_epNotTarget_e', i_str), 'savenew', strcat(path, '\\Extracted_Epochs\\', file_name, '_epNotTarget_e', i_str,'.set'), 'gui','off'); 
        EEG = eeg_checkset( EEG );
        xmin = EEG.xmin * 1000;
        xmax = EEG.xmax * 1000;
        % Exporting EEG data and spectra of the single epoch
        pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_e', i_str, '_EEG.csv'),'transpose','on','precision',5);
        figure; spect = pop_spectopo(EEG, 1, [xmin      xmax], 'EEG' , 'freqrange',[1 128],'electrodes','off');
        csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_e', i_str, '_EEG-SPECTRA.csv'), spect);
        EEG = eeg_checkset( EEG );
        % Extracting ERSP for each channel
        for c = 1:EEG.nbchan
            caption = EEG.chanlocs(1,c).labels;
            figure; ersp = pop_newtimef( EEG, 1, c, [xmin  xmax], [3         0.5] , 'topovec', 1, 'elocs', EEG.chanlocs, 'chaninfo', EEG.chaninfo, 'caption', caption, 'baseline',[0],'winsize', 256, 'freqs', [0 60], 'plotphase', 'off', 'padratio', 1);
            csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_e', i_str, '_ERSP-', caption,'.csv'), ersp);
        end 
        % Exporting ICA_components data and spectra of the single epoch, if ICA was performed
        if size(EEG.icaweights) ~= 0
            pop_export(EEG,strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_e', i_str, '_ICA.csv'),'ica', 'on', 'transpose','on','precision',5);
            figure; spect = pop_spectopo(EEG, 0, [xmin      xmax], 'EEG' , 'freq', [10], 'plotchan', 0, 'icacomps', [1:4], 'nicamaps', 5, 'freqrange',[1 100],'electrodes','off');
            csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_e', i_str, '_ICA-SPECTRA.csv'), spect);
            
            [n_components, ~] = size(EEG.icaweights);
            for c = 1:n_components
                figure; ersp = pop_newtimef( EEG, 0, c, [xmin  xmax], [3         0.5] , 'topovec', 1, 'elocs', EEG.chanlocs, 'chaninfo', EEG.chaninfo, 'caption', strcat('COMP0', c), 'baseline',[0],'winsize', 256, 'freqs', [0 60], 'plotphase', 'off', 'padratio', 1);
                csvwrite(strcat(path, '\\Extracted_Epochs\\data\\', file_name, '_epNotTarget_e', i_str, '_ERSP-', strcat('COMP0', c),'.csv'), ersp);
            end 
        end
        
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, CURRENTSET, 'retrieve', STARTING_DS, 'study',0);
        EEG = eeg_checkset( EEG ); 
        close all;
    end
    
end

