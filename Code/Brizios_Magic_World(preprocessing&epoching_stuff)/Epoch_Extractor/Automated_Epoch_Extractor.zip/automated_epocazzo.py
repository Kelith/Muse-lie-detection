# -*- coding: utf-8 -*-
"""
Created on Tue Jul  2 15:36:55 2019

@author: Fabrizio Zoleo
"""

import matlab.engine as mateng
import sys

from datetime import datetime
from os import listdir, system, mkdir
from os.path import join, exists, isfile

def isRoundFolder(fname):
   return ( "R" in fname.upper()) or ("ROUND" in fname.upper() ) 

def isSelectedStep(fname, step):
    step_i = fname.upper().find(step.upper())
    if step_i >= 0:
        step_i += len(step)
        return ( step.upper() in fname.upper() ) and ( "HPF0.1" in fname.upper() ) and ( fname[step_i:].upper() == ".SET" )
    else:
        return False
    
# Cleaning the shell
if sys.platform == "linux" or sys.platform == "linux2":
    system("clear")
elif sys.platform == "win32":
    system("cls")
    system("mode con: cols=130 lines=40")

path = ""
# Reading PATH parameter from command line or asking it in input if not provided
if len(sys.argv) == 3:
    path = sys.argv[1]
    step = sys.argv[2]
elif len(sys.argv) == 2:
    path = sys.argv[1]
    step = input("Please insert the STEP_NAME of pre-processing on which epochs must be extracted.\nHINT: Each processing step name is separated by '_' in the dataset name.\n")
else:
    path = input("Please insert the folder path of the Project_Folder containing the Subjects to be processed:\n")
    step = input("Please insert the STEP_NAME of pre-processing on which epochs must be extracted.\nHINT: Each processing step name is separated by '_' in the dataset name.\n")

subj_name = input("Please insert the Subject_NAME to be processed. Leave empty if all subject must be processed:\n")

print("\nWARNING: to be correctly processed, the folder structure must be of the type:\n-ProjectFolder\n\t-SubjectFolder1\n\t\t-R1\n\t\t-R2\n\t\t .\n\t\t .\n\t\t .\n\t\t-RN\n\t-SubjectFolder2\n\t   .\n\t   .\n\t   .")
input("\nPress ENTER to start . . .\n")

if len(subj_name) > 0:
    print("Epochs, data and spectra will be extracted from subject {} .".format(subj_name))
    subject_folders = [s for s in listdir(path) if s.upper() == subj_name.upper()]
else:
    print("Epochs, data and spectra will be extracted from  ALL subjects!")
    subject_folders = listdir(path)
    
# Starting MATLAB engine
print("\nLoading study folders . . .")
engine = mateng.start_matlab()
start = datetime.now()
print("\nEpoch extraction started at {}".format(start) )

for subj in subject_folders:
    print("\nSubject folder: {}".format(subj))
    current_path = join(path, subj)

    for round_folder in listdir(current_path):
        if isRoundFolder(round_folder) and not isfile( join(current_path, round_folder) ) :
            print("\nRound Directory:\t{}\n\n".format(round_folder))
            if not exists(join(current_path, round_folder, "Extracted_Epochs")):
                mkdir(join(current_path, round_folder, "Extracted_Epochs"), 0o777)
                mkdir(join(current_path, round_folder, "Extracted_Epochs", "data"), 0o777)
# Retrieving datasets with selected pre-processing step      
            selected_ds = [x for x in listdir( join(current_path, round_folder) ) if isSelectedStep(x, step) ]
            if len(selected_ds) > 0:
                for ds in selected_ds:
                    print("\nExtracting epochs on dataset:\t {} . . .\n\n".format(ds))
                    t_path = join(current_path, round_folder)
                    t_fname = ds[: ds.rfind('.')]
                    engine.extract_epochs(t_path, t_fname, nargout=0)
                    print("\nExtraction complete!\n")
            else:
                print("No dataset with the specified steps was found for this round.")
    print("\n\n")
    
end = datetime.now()
print("\n\nEpoch extraction completed at {}\nElapsed time: {}".format(end, (end - start)) )
print("\n\nCheck the folder ""Extracted_Epochs"" in each round folder of your subjects!")
