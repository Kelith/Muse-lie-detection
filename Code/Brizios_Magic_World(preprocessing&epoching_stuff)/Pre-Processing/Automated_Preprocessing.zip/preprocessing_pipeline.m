function preprocessing_pipeline(dir_path, file_name, locs_path, r, hpf, std, ICA_mtx)
    round = strcat('\\R', r,'\\');
    path = strcat(dir_path, round);
    fname = file_name;
    % Loading the MuseMonitor CSV dataset with a 256 sampling rate
    [ALLEEG EEG CURRENTSET ALLCOM] = eeglab;
    EEG = pop_musemonitor(strcat(path,fname,'.csv'), 'srate','256');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 0,'setname',fname,'gui','off'); 
    EEG = eeg_checkset( EEG );
    EEG = pop_rmbase( EEG, [EEG.xmin      EEG.xmax]);
    [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    % Loading Channel info
    EEG=pop_chanedit(EEG, 'lookup', locs_path,'eval','chans = pop_chancenter( chans, [],[]);');
    [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    EEG = eeg_checkset( EEG );
    % Loading Events
    EEG = pop_importevent( EEG, 'event',strcat(path,fname,'_events.txt'),'fields',{'latency' 'type'},'skipline',1,'timeunit',1);
    [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    EEG = eeg_checkset( EEG );
    EEG = pop_saveset( EEG, 'filename',strcat(fname,'.set'),'filepath',path);
    [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    % Applying HIGH-PASS filter
    EEG = eeg_checkset( EEG );
    EEG = pop_eegfiltnew(EEG, [],hpf,[],1,[],0);
    steps = strcat('_hpf', num2str(hpf));
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 1,'setname',strcat(fname,steps),'savenew',strcat(path, fname, steps, '.set'),'gui','off'); 
    EEG = eeg_checkset( EEG );
    % Applying CLEANLINE for cleaning the artifact at 50 Hz
    EEG = pop_cleanline(EEG, 'bandwidth',2,'chanlist',[1:4] ,'computepower',1,'linefreqs',50,'normSpectrum',0,'p',0.01,'pad',2,'plotfigures',0,'scanforlines',1,'sigtype','Channels','tau',100,'verb',1,'winsize',4,'winstep',4);
    steps = strcat(steps, '_cleanline');
    [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 2,'setname',strcat(fname,steps),'savenew',strcat(path, fname, steps, '.set'),'gui','off'); 
    EEG = eeg_checkset( EEG );
    % If STD > 0 ASR will be performed with this value, 
    % otherwise the Automatic Continuous Data Rejection will be performed for
    % cleaning from major artifacts (only if there is no ICA_WEIGHTS_MATRIX
    % loaded, which means that we are in the first pass of pre-processing).
    if std > 0
        EEG = clean_rawdata(EEG, 'off', 'off', 'off', 'off', std, 'off', 'availableRAM_GB', 8.22);
        EEG = eeg_checkset( EEG );
        steps = strcat(steps, '_ASR', num2str(std));
        EEG = pop_saveset( EEG, 'filename', strcat(fname, steps, '.set'),'filepath',path);
        [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    elseif (std <= 0) && ( isempty(ICA_mtx) )
        [~, Rejected_Samples] = pop_rejcont(EEG, 'elecrange',[1:4] ,'freqlimit',[40 128] ,'threshold',10,'epochlength',0.5,'contiguous',4,'addlength',0.25,'onlyreturnselection', 'on','taper','hamming');
        EEG = pop_select( EEG,'nopoint',Rejected_Samples);
        EEG = eeg_checkset( EEG );
        steps = strcat(steps, '_Bad-Data-Rejected');
        EEG = pop_saveset( EEG, 'filename', strcat(fname, steps, '.set'),'filepath',path);
        [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    end
    % If there is no ICA_WEIGHT_MATRIX we are in the 1st pass and it must be
    % computed; otherwise, there is a file with an already computed
    % ICA_WEIGHT_MATRIX to apply and we are in the 2nd pass.
    if isempty(ICA_mtx)
        EEG = eeg_checkset( EEG );
        EEG = pop_runica(EEG, 'extended',1,'interupt','on');
        steps = strcat(steps, '_ICA');
        [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
        EEG = pop_saveset( EEG, 'filename',strcat(fname, steps, '.set'),'filepath', path);
        [ALLEEG EEG CURRENTSET] = pop_newset(ALLEEG, EEG, 3,'savenew',strcat(path, fname, steps, '.set'),'gui','off'); 
        EEG = eeg_checkset( EEG );
        pop_expica(EEG, 'weights', strcat(path,'ica_weights'));
        EEG = eeg_checkset( EEG );
    else
        EEG = pop_editset(EEG, 'icachansind', [], 'icaweights', strcat(path,ICA_mtx), 'icasphere', 'eye(4)');
        steps = strcat(steps, '_ICA');
        EEG = pop_saveset( EEG, 'filename',strcat(fname, steps, '.set'),'filepath', path);
        [ALLEEG EEG] = eeg_store(ALLEEG, EEG, CURRENTSET);
    end
end